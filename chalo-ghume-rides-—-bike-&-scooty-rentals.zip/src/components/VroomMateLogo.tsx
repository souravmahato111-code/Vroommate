import React from 'react';

interface VroomMateLogoProps {
  src?: string;
  className?: string;
  alt?: string;
  variant?: 'full' | 'icon' | 'horizontal';
  showTagline?: boolean;
}

export const VroomMateLogo: React.FC<VroomMateLogoProps> = ({
  src,
  className = '',
  alt = 'Vroommate Logo',
  variant = 'horizontal',
  showTagline = false,
}) => {
  // If an external src is explicitly provided, render as responsive img
  if (src) {
    return (
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        className={className || 'h-9 sm:h-11 w-auto max-w-[200px] object-contain'}
      />
    );
  }

  // Exact Brand Palette
  const neon = '#22f054';

  if (variant === 'icon') {
    return (
      <svg
        viewBox="0 0 500 320"
        className={className || 'w-full h-full object-contain'}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label={alt}
      >
        {/* Speed Lines */}
        <path d="M 50 85 L 160 85" stroke={neon} strokeWidth="20" strokeLinecap="round" />
        <path d="M 75 130 L 168 130" stroke={neon} strokeWidth="20" strokeLinecap="round" />
        <path d="M 120 175 L 200 175" stroke={neon} strokeWidth="20" strokeLinecap="round" />

        {/* Dynamic V-Cowl & Aerodynamic Frame */}
        <path
          d="M 120 20
             L 212 20
             C 218 20 224 23 228 29
             L 294 165
             L 365 20
             C 370 20 440 16 480 62
             C 522 112 510 180 465 220
             C 445 238 402 248 368 248
             C 338 248 328 225 345 205
             C 364 185 402 180 428 160
             C 452 140 448 105 428 85
             C 408 65 370 68 350 105
             L 264 285
             C 256 300 242 305 232 295
             L 212 260
             Z"
          fill={neon}
        />

        {/* Lower Swingarm / Fork Link */}
        <path
          d="M 268 245
             Q 308 245 328 220
             L 362 255
             C 332 285 288 275 258 255
             Z"
          fill={neon}
        />

        {/* Motorcycle Wheel */}
        <circle cx="405" cy="180" r="62" stroke="#FFFFFF" strokeWidth="20" fill="none" />
        <circle cx="405" cy="180" r="52" fill="#000000" />
        <circle cx="405" cy="180" r="22" fill="#FFFFFF" />
        <circle cx="405" cy="180" r="10" fill="#000000" />
      </svg>
    );
  }

  if (variant === 'full') {
    return (
      <div className={`flex flex-col items-center select-none bg-black p-4 rounded-2xl ${className}`}>
        {/* Emblem */}
        <div className="w-full max-w-[260px]">
          <svg
            viewBox="0 0 500 320"
            className="w-full h-auto drop-shadow-[0_0_16px_rgba(34,240,84,0.35)]"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label={alt}
          >
            <path d="M 50 85 L 160 85" stroke={neon} strokeWidth="20" strokeLinecap="round" />
            <path d="M 75 130 L 168 130" stroke={neon} strokeWidth="20" strokeLinecap="round" />
            <path d="M 120 175 L 200 175" stroke={neon} strokeWidth="20" strokeLinecap="round" />

            <path
              d="M 120 20
                 L 212 20
                 C 218 20 224 23 228 29
                 L 294 165
                 L 365 20
                 C 370 20 440 16 480 62
                 C 522 112 510 180 465 220
                 C 445 238 402 248 368 248
                 C 338 248 328 225 345 205
                 C 364 185 402 180 428 160
                 C 452 140 448 105 428 85
                 C 408 65 370 68 350 105
                 L 264 285
                 C 256 300 242 305 232 295
                 L 212 260
                 Z"
              fill={neon}
            />

            <circle cx="405" cy="180" r="62" stroke="#FFFFFF" strokeWidth="20" fill="none" />
            <circle cx="405" cy="180" r="52" fill="#000000" />
            <circle cx="405" cy="180" r="22" fill="#FFFFFF" />
            <circle cx="405" cy="180" r="10" fill="#000000" />
          </svg>
        </div>

        {/* Wordmark */}
        <div className="mt-3 text-center">
          <div className="font-display font-black italic tracking-tighter text-3xl sm:text-4xl text-white uppercase leading-none">
            <span>VROOM</span>
            <span style={{ color: neon }}>MATE</span>
          </div>

          <div className="mt-2 flex items-center justify-center gap-2.5">
            <span className="w-7 h-[2px] rounded-full" style={{ backgroundColor: neon }} />
            <span className="text-[11px] font-bold tracking-[0.4em] text-white uppercase pl-[0.4em]">
              RIDES
            </span>
            <span className="w-7 h-[2px] rounded-full" style={{ backgroundColor: neon }} />
          </div>
        </div>
      </div>
    );
  }

  // Default 'horizontal' lockup for Navbar and Footer
  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Icon Emblem */}
      <div className="relative shrink-0 flex items-center justify-center">
        <svg
          viewBox="0 0 500 320"
          className="w-10 h-7 sm:w-12 sm:h-8 drop-shadow-[0_0_10px_rgba(34,240,84,0.35)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          role="img"
          aria-label={alt}
        >
          {/* Speed Lines */}
          <path d="M 50 85 L 160 85" stroke={neon} strokeWidth="22" strokeLinecap="round" />
          <path d="M 75 130 L 168 130" stroke={neon} strokeWidth="22" strokeLinecap="round" />
          <path d="M 120 175 L 200 175" stroke={neon} strokeWidth="22" strokeLinecap="round" />

          {/* V Shape Body */}
          <path
            d="M 120 20
               L 212 20
               C 218 20 224 23 228 29
               L 294 165
               L 365 20
               C 370 20 440 16 480 62
               C 522 112 510 180 465 220
               C 445 238 402 248 368 248
               C 338 248 328 225 345 205
               C 364 185 402 180 428 160
               C 452 140 448 105 428 85
               C 408 65 370 68 350 105
               L 264 285
               C 256 300 242 305 232 295
               L 212 260
               Z"
            fill={neon}
          />

          {/* Wheel */}
          <circle cx="405" cy="180" r="62" stroke="#FFFFFF" strokeWidth="22" fill="none" />
          <circle cx="405" cy="180" r="51" fill="#000000" />
          <circle cx="405" cy="180" r="22" fill="#FFFFFF" />
          <circle cx="405" cy="180" r="10" fill="#000000" />
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col justify-center">
        <div className="font-display font-black italic tracking-tight text-xl sm:text-2xl text-white uppercase leading-none whitespace-nowrap">
          <span>VROOM</span>
          <span style={{ color: neon }}>MATE</span>
        </div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span className="w-3.5 h-[1.5px] rounded-full" style={{ backgroundColor: neon }} />
          <span className="text-[9px] font-bold tracking-[0.3em] text-slate-300 uppercase pl-[0.3em] leading-none">
            RIDES
          </span>
          <span className="w-3.5 h-[1.5px] rounded-full" style={{ backgroundColor: neon }} />
        </div>
      </div>
    </div>
  );
};
